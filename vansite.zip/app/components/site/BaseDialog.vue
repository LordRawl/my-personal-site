<script setup lang="ts">
import { gsap } from 'gsap'
import { applyTypography } from '~/utils/typography'

const open = defineModel<boolean>({ default: false })

const props = defineProps<{
  labelledby: string
  origin?: { x: number; y: number }
}>()

const smooth = useSmoothScroll()
const el = ref<HTMLDialogElement | null>(null)
const reduce = import.meta.client
  ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
  : false

watch(open, async (value) => {
  const dialog = el.value
  if (!dialog) return
  if (!value) {
    if (dialog.open) dialog.close()
    return
  }

  await nextTick()
  if (!dialog.open) dialog.showModal()
  smooth.stop()
  applyTypography(dialog)
  if (reduce) return

  const rect = dialog.getBoundingClientRect()
  const x = (props.origin?.x ?? 0) - rect.left
  const y = (props.origin?.y ?? 0) - rect.top
  gsap.fromTo(
    dialog,
    { clipPath: `circle(0px at ${x}px ${y}px)` },
    {
      clipPath: `circle(150% at ${x}px ${y}px)`,
      duration: 0.7,
      ease: 'power3.out',
      clearProps: 'clipPath',
    },
  )
})

onMounted(() => {
  const dialog = el.value
  if (!dialog) return
  dialog.addEventListener('close', () => {
    open.value = false
    smooth.start()
  })
  dialog.addEventListener('click', (e) => {
    if (e.target === dialog) open.value = false
  })
})

onBeforeUnmount(() => smooth.start())
</script>

<template>
  <dialog ref="el" class="dialog" data-lenis-prevent :aria-labelledby="labelledby">
    <slot />
  </dialog>
</template>
