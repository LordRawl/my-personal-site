<script setup lang="ts">
const { open, origin, close } = useGameDialog()
</script>

<template>
  <BaseDialog
    v-model="open"
    labelledby="game-dialog-title"
    class="dialog--game"
    :origin="origin"
  >
    <div class="dialog__body">
      <button class="dialog__close" type="button" @click="close">Закрыть ✕</button>
      <p class="mono dialog__meta">Пасхалка</p>
      <h3 id="game-dialog-title" class="dialog__title">Мини-игра</h3>
      <div class="dialog__frame">Здесь откроется игра.</div>
    </div>
  </BaseDialog>
</template>

<style>
.dialog--game {
  width: min(64rem, 94vw);
}
.dialog__frame {
  position: relative;
  aspect-ratio: 16/10;
  max-height: calc(100svh - 16rem);
  width: 100%;
  margin-top: 1.4rem;
  border-radius: 1.1rem;
  overflow: hidden;
  background: #0b0705;
  display: grid;
  place-items: center;
  color: #b9a99a;
  text-align: center;
  padding: 1rem;
  font: 500 0.85rem var(--fm);
}
@media (max-width: 700px) {
  .dialog--game {
    width: 100vw;
    max-width: 100vw;
  }
}
</style>
