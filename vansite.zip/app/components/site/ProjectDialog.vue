<script setup lang="ts">
const { project, origin, close } = useProjectDialog()

const visible = computed({
  get: () => Boolean(project.value),
  set: (value) => {
    if (!value) close()
  },
})
</script>

<template>
  <BaseDialog
    v-model="visible"
    labelledby="project-dialog-title"
    :origin="origin"
  >
    <div v-if="project" class="dialog__body">
      <button class="dialog__close" type="button" @click="close">Закрыть ✕</button>
      <p class="mono dialog__meta">
        {{ project.tag }} · {{ project.company }} · {{ project.period }}
      </p>
      <h3 id="project-dialog-title" class="dialog__title">{{ project.title }}</h3>
      <p class="dialog__text">{{ project.description }}</p>
      <ul class="dialog__points">
        <li v-for="point in project.points" :key="point">{{ point }}</li>
      </ul>
      <p class="dialog__metric">
        {{ project.metric.value
        }}<small class="dialog__metric-label">{{ project.metric.label }}</small>
      </p>
      <ul class="dialog__chips">
        <li v-for="tool in project.stack" :key="tool" class="dialog__chip">{{ tool }}</li>
      </ul>
    </div>
  </BaseDialog>
</template>
