<script setup lang="ts">
withDefaults(
  defineProps<{
    fx: 'ridge' | 'wave' | 'caret' | 'slash'
    num?: string
    from?: 'dark' | 'light' | 'red'
    to?: 'dark' | 'light' | 'red'
    flip?: boolean
    shift?: string
    bare?: boolean
  }>(),
  { num: '', from: 'dark', to: 'dark', flip: false, shift: '', bare: false },
)
</script>

<template>
  <div
    class="seam"
    :data-fx="fx"
    :data-num="num"
    :data-from="from"
    :data-to="to"
    :data-flip="flip ? '1' : ''"
    :data-bare="bare ? '1' : ''"
    :style="shift ? { '--sh': shift } : undefined"
    aria-hidden="true"
  />
</template>
