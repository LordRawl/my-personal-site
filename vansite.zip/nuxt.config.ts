import tailwindcss from '@tailwindcss/vite'

// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  compatibilityDate: '2025-07-15',
  devtools: { enabled: true },
  css: ['~/assets/css/main.css'],
  modules: ['@nuxt/eslint', '@nuxt/fonts'],
  fonts: {
    processCSSVariables: false,
    families: [
      { name: 'Unbounded', provider: 'google', weights: [700, 900], subsets: ['cyrillic', 'latin'] },
      {
        name: 'JetBrains Mono',
        provider: 'google',
        weights: [400, 500, 700],
        subsets: ['cyrillic', 'latin'],
      },
      {
        name: 'Oswald',
        provider: 'google',
        weights: [500, 700],
        subsets: ['cyrillic', 'latin'],
      },
    ],
  },
  components: [
    {
      path: '~/components',
      pathPrefix: false,
    },
  ],
  runtimeConfig: {
    telegramBotToken: '',
    telegramChatId: '',
    public: {
      siteUrl: '',
    },
  },
  vite: {
    plugins: [tailwindcss()],
  },
  app: {
    head: {
      htmlAttrs: { lang: 'ru' },
      title: 'Frontend-разработчик Иван Есин — Vue 3, Nuxt, TypeScript',
      meta: [
        { name: 'viewport', content: 'width=device-width, initial-scale=1.0' },
        {
          name: 'description',
          content:
            'Frontend-разработчик: 9 лет опыта, 80+ проектов на Vue 3, Nuxt и TypeScript. Высоконагруженные интерфейсы, дизайн-система, SSR. Открыт к удалённой работе.',
        },
        { name: 'author', content: 'Иван Есин' },
        { name: 'theme-color', content: '#0b0705' },
        {
          property: 'og:title',
          content: 'Frontend-разработчик Иван Есин — Vue 3, Nuxt, TypeScript',
        },
        {
          property: 'og:description',
          content:
            '9 лет опыта, 80+ проектов: высоконагруженные интерфейсы, дизайн-система, SSR. Открыт к удалённой работе.',
        },
        { property: 'og:site_name', content: 'Иван Есин' },
        { property: 'og:type', content: 'website' },
        { property: 'og:image', content: '/og.png' },
        { property: 'og:image:width', content: '1200' },
        { property: 'og:image:height', content: '630' },
        {
          property: 'og:image:alt',
          content: 'Иван Есин — фронтенд-разработчик Vue, Nuxt, TypeScript',
        },
        { property: 'og:locale', content: 'ru_RU' },
        { name: 'twitter:card', content: 'summary_large_image' },
        {
          name: 'twitter:title',
          content: 'Frontend-разработчик Иван Есин — Vue 3, Nuxt, TypeScript',
        },
        {
          name: 'twitter:description',
          content: '9 лет опыта, 80+ проектов: высоконагруженные интерфейсы, дизайн-система, SSR',
        },
        { name: 'twitter:image', content: '/og.png' },
        {
          name: 'google-site-verification',
          content: 'D8pwAXJQOWb-_5Fuy9wRscagleLgr7qV5wpDaF-wbI4',
        },
      ],
      link: [
        { rel: 'icon', type: 'image/svg+xml', href: '/favicons/favicon.svg' },
        { rel: 'icon', type: 'image/png', sizes: '16x16', href: '/favicons/favicon-16x16.png' },
        { rel: 'icon', type: 'image/png', sizes: '32x32', href: '/favicons/favicon-32x32.png' },
        { rel: 'icon', type: 'image/png', sizes: '48x48', href: '/favicons/favicon-48x48.png' },
        { rel: 'icon', type: 'image/png', sizes: '192x192', href: '/favicons/favicon-192x192.png' },
        { rel: 'apple-touch-icon', sizes: '180x180', href: '/favicons/favicon-180x180.png' },
      ],
    },
  },
})
